import express from 'express';
import mysql from 'mysql2';
import redis from 'redis';
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

// App Configuration (using environment variables)
const config = {
    useMysql: process.env.USE_MYSQL === 'true', // Enable MySQL via environment variable
    useRedis: process.env.USE_REDIS === 'true', // Enable Redis via environment variable
    mysqlConfig: {
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD,
        database: process.env.MYSQL_DATABASE,
        port: process.env.MYSQL_PORT
    },
    redisConfig: {
        host: process.env.REDIS_HOST,
        port: process.env.REDIS_PORT
    },
    appConfig: {
        port: process.env.APP_PORT,
    }
};

// Initialize Express
const app = express();
app.use(express.json());

// Conditional MySQL Setup
let db;
if (config.useMysql) {
    db = mysql.createConnection(config.mysqlConfig);

    db.connect((err) => {
        if (err) {
            console.error('Error connecting to MySQL:', err.message);
        } else {
            console.log('Connected to MySQL');
        }
    });
}

// Conditional Redis Setup
let redisClient;
if (config.useRedis) {
    redisClient = redis.createClient({
        socket: {
            host: config.redisConfig.host,
            port: config.redisConfig.port,
        }
    });

    redisClient.connect().then(() => {
        console.log('Connected to Redis');
    }).catch((err) => {
        console.error('Error connecting to Redis:', err.message);
    });
}

// Routes
app.get('/', (req, res) => {
    if (config.useMysql && config.useRedis) {
        res.send('Welcome to the Node.js Application with MySQL and Redis');
    } else if (config.useMysql) {
        res.send('Welcome to the Node.js Application with MySQL');
    } else {
        res.send('Welcome to the Node.js Application');
    }
});

app.get('/users', async (req, res) => {
    if (config.useRedis) {
        const cachedUsers = await redisClient.get('users');
        if (cachedUsers) {
            return res.json(JSON.parse(cachedUsers));
        }
    }

    if (config.useMysql) {
        db.query('SELECT * FROM users', async (err, results) => {
            if (err) {
                res.status(500).send(err.message);
            } else {
                if (config.useRedis) {
                    await redisClient.set('users', JSON.stringify(results), 'EX', 3600); // Cache for 1 hour
                }
                res.json(results);
            }
        });
    } else {
        res.status(500).send('MySQL is not configured');
    }
});

app.post('/users', async (req, res) => {
    const { name, email } = req.body;

    if (config.useMysql) {
        db.query('INSERT INTO users (name, email) VALUES (?, ?)', [name, email], async (err, result) => {
            if (err) {
                res.status(500).send(err.message);
            } else {
                if (config.useRedis) {
                    await redisClient.del('users'); // Clear cache
                }
                res.status(201).send(`User added with ID: ${result.insertId}`);
            }
        });
    } else {
        res.status(500).send('MySQL is not configured');
    }
});

// Start the Server
app.listen(config.appConfig.port, '0.0.0.0', () => {
    console.log(`Server is running on http://localhost:${config.appConfig.port}`);
});